CREA LA BASE DE DATOS CON EL ARCHIVO "datacenter.sql"

COLOCA TODO LO DEMAS EN LA CARPETA CORRESPONDIENTE DE TU SERVIDOR WEB

CAMBIA LA IP, USUARIO Y CONTRASEÑA DE LOS ARCHIVOS "bd/conexion2.php" y "bd/conexion.php"

usuarios por default

email: admin@admin.com
contraseña: admin

email: consulta@consulta.com
contraseña: consulta

